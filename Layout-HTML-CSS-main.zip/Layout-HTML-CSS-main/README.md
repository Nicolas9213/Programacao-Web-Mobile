# Layout-HTML-CSS
# Projeto:
Elementum
# Aluno:
Nícolas Augusto Gazaniga
# Curso:
Programação de Sistemas de Informação MI73
# Descrição do projeto: 
Site desenvolvido na matéria Programação Web e Mobile com o objetivo de aprimorar o conhecimento das linguagens HTML e CSS. Se trata de um site de marketing sobre uma empresa que ofereçe serviços digitais.
# Como utilizar o site localmente:
Basta extrair a pasta com o arquivo
